import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error) {
    return {
      hasError: true,
      message: error?.message || 'An unexpected rendering error occurred.'
    };
  }

  handleReset = () => {
    this.setState({ hasError: false, message: '' });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
          <div className="max-w-md w-full bg-white border border-red-200 rounded-xl p-6 shadow-sm text-center">
            <AlertTriangle className="w-9 h-9 text-red-600 mx-auto mb-3" />
            <h2 className="text-lg font-bold text-slate-900">CareCompass Recovery Mode</h2>
            <p className="text-xs text-slate-600 mt-1.5">{this.state.message}</p>
            <button
              onClick={this.handleReset}
              className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reload Application View
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
