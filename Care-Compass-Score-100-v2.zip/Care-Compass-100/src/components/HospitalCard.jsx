import React from 'react';
import {
  MapPin,
  Phone,
  Clock,
  Activity,
  ShieldAlert,
  CheckCircle2,
  CalendarPlus,
  RotateCcw,
  Gauge,
  Wind
} from 'lucide-react';

const WARDS = [
  { key: 'icu', label: 'ICU' },
  { key: 'general', label: 'General' },
  { key: 'nicu', label: 'NICU' },
  { key: 'isolation', label: 'Isolation' }
];

export default function HospitalCard({
  hospital,
  isSelected,
  onSelect,
  onReserveBed,
  onReleaseBed,
  activeReservation
}) {
  const icuAvail = hospital.beds.icu.available;
  const status =
    icuAvail === 0
      ? { label: 'ICU Full', classes: 'bg-red-100 text-red-700 border-red-200' }
      : icuAvail <= 3
      ? { label: 'Critical Capacity', classes: 'bg-amber-100 text-amber-800 border-amber-200' }
      : { label: 'Accepting Admissions', classes: 'bg-emerald-100 text-emerald-800 border-emerald-200' };

  return (
    <div
      onClick={() => onSelect(hospital.id)}
      className={`bg-white rounded-xl border p-5 transition cursor-pointer shadow-sm ${
        isSelected ? 'border-blue-600 ring-2 ring-blue-100' : 'border-slate-200 hover:border-slate-300'
      }`}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="text-lg font-bold text-slate-900">{hospital.name}</h3>
            <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${status.classes}`}>
              {status.label}
            </span>
            <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
              <Gauge className="w-3 h-3" />
              Triage Index: {hospital.triageScore}/100
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>{hospital.address}</span>
          </p>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {hospital.specialties.map((spec) => (
              <span
                key={spec}
                className="text-[11px] font-medium bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md"
              >
                {spec}
              </span>
            ))}
          </div>
        </div>

        <div className="text-right">
          <div className="inline-flex items-center gap-1.5 bg-blue-50 text-blue-800 font-bold text-sm px-3 py-1 rounded-lg border border-blue-100">
            <span>{hospital.distanceKm} km</span>
            <span className="text-blue-400">•</span>
            <span>~{hospital.etaMinutes} min</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-end gap-1">
            <Clock className="w-3 h-3" /> Updated {hospital.lastUpdated}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4">
        {WARDS.map(({ key, label }) => {
          const ward = hospital.beds[key];
          const pct = ward.total > 0 ? Math.round((ward.available / ward.total) * 100) : 0;
          const isZero = ward.available === 0;
          return (
            <div key={key} className="p-3 rounded-lg border bg-slate-50 border-slate-200/80">
              <div className="flex items-center justify-between text-xs font-medium text-slate-600">
                <span>{label}</span>
                <span className="text-[11px] text-slate-400">{pct}% open</span>
              </div>
              <div className="mt-1 flex items-baseline gap-1">
                <span className={`text-xl font-extrabold ${isZero ? 'text-red-600' : 'text-slate-900'}`}>
                  {ward.available}
                </span>
                <span className="text-xs text-slate-500">/ {ward.total}</span>
              </div>
            </div>
          );
        })}
      </div>

      <div
        className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
          <span className="inline-flex items-center gap-1 bg-slate-100 px-2 py-1 rounded font-medium">
            <Activity className="w-3.5 h-3.5 text-emerald-600" />
            O₂ Reserve: {hospital.oxygenReservePct}%
          </span>
          <span className="inline-flex items-center gap-1 bg-slate-100 px-2 py-1 rounded font-medium">
            <Wind className="w-3.5 h-3.5 text-cyan-600" />
            Ventilators: {hospital.ventilatorsAvailable}
          </span>
          <span className="inline-flex items-center gap-1 bg-slate-100 px-2 py-1 rounded font-medium">
            <ShieldAlert className="w-3.5 h-3.5 text-blue-600" />
            {hospital.traumaLevel}
          </span>
          <a
            href={`tel:${hospital.phone}`}
            className="inline-flex items-center gap-1 text-blue-700 hover:underline font-medium ml-1"
          >
            <Phone className="w-3.5 h-3.5" />
            {hospital.phone}
          </a>
        </div>

        <div className="flex items-center gap-2">
          {activeReservation ? (
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1.5 rounded-lg">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Held: {activeReservation.ward.toUpperCase()} ({activeReservation.code})
              </span>
              <button
                onClick={() => onReleaseBed(hospital.id)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 px-2.5 py-1.5 rounded-lg transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Release
              </button>
            </div>
          ) : (
            <>
              <button
                disabled={hospital.beds.icu.available === 0}
                onClick={() => onReserveBed(hospital.id, 'icu')}
                className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed transition"
              >
                <CalendarPlus className="w-3.5 h-3.5" />
                Hold ICU Bed
              </button>
              <button
                disabled={hospital.beds.general.available === 0}
                onClick={() => onReserveBed(hospital.id, 'general')}
                className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-slate-800 text-white hover:bg-slate-900 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed transition"
              >
                Hold General
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
