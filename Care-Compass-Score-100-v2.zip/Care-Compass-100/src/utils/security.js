/**
 * Sanitizes free-text inputs to prevent XSS/script/event-handler injection
 * in search queries, patient transfer notes, and dispatcher audit logs.
 */
export function sanitizeText(input) {
  if (typeof input !== 'string') return '';
  return input
    .replace(/[<>]/g, '')
    .replace(/javascript:/gi, '')
    .replace(/data:text\/html/gi, '')
    .replace(/on\w+\s*=/gi, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 140);
}

/**
 * Enforces strict integer bed bounds within [0, maxCapacity].
 */
export function clampBedCount(value, maxCapacity) {
  const max = Math.max(0, Number.parseInt(maxCapacity, 10) || 0);
  const parsed = Number.parseInt(value, 10);
  if (Number.isNaN(parsed)) return 0;
  return Math.max(0, Math.min(max, parsed));
}
