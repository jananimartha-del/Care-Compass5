import React, { useEffect, useMemo, useState } from 'react';
import {
  HeartPulse,
  Search,
  SlidersHorizontal,
  LocateFixed,
  Shield,
  BedDouble,
  AlertCircle,
  RotateCcw,
  Radio,
  Server
} from 'lucide-react';
import { DEFAULT_USER_LOCATION, INITIAL_HOSPITALS } from './data/mockHospitals.js';
import {
  calculateHaversineDistance,
  computeTriageScore,
  estimateTravelMinutes
} from './utils/haversine.js';
import { clampBedCount, sanitizeText } from './utils/security.js';
import HospitalMap from './components/HospitalMap.jsx';
import HospitalCard from './components/HospitalCard.jsx';
import AdminConsole from './components/AdminConsole.jsx';

const STORAGE_KEY = 'carecompass_state_v4';

export default function App() {
  const [hospitals, setHospitals] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      return Array.isArray(saved?.hospitals) && saved.hospitals.length > 0
        ? saved.hospitals
        : INITIAL_HOSPITALS;
    } catch {
      return INITIAL_HOSPITALS;
    }
  });
  const [userLocation, setUserLocation] = useState(DEFAULT_USER_LOCATION);
  const [activeTab, setActiveTab] = useState('finder');
  const [searchQuery, setSearchQuery] = useState('');
  const [wardFilter, setWardFilter] = useState('all');
  const [traumaFilter, setTraumaFilter] = useState('all');
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [sortBy, setSortBy] = useState('triage');
  const [selectedHospitalId, setSelectedHospitalId] = useState(INITIAL_HOSPITALS[0].id);
  const [reservations, setReservations] = useState({});
  const [auditLogs, setAuditLogs] = useState([]);
  const [geoStatus, setGeoStatus] = useState('');
  const [liveTelemetry, setLiveTelemetry] = useState(false);
  const [apiConnected, setApiConnected] = useState(false);

  useEffect(() => {
    let active = true;
    fetch('/api/hospitals')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (active && data?.hospitals?.length) {
          setHospitals(data.hospitals);
          setApiConnected(true);
        }
      })
      .catch(() => {
        if (active) setApiConnected(false);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ hospitals }));
    } catch {
      // Ignore storage quota errors
    }
  }, [hospitals]);

  useEffect(() => {
    if (!liveTelemetry) return undefined;
    const interval = setInterval(() => {
      setHospitals((prev) => {
        const idx = Math.floor(Math.random() * prev.length);
        const wards = ['icu', 'general', 'nicu', 'isolation'];
        const wardKey = wards[Math.floor(Math.random() * wards.length)];
        const delta = Math.random() > 0.5 ? 1 : -1;

        return prev.map((h, i) => {
          if (i !== idx) return h;
          const nextAvail = clampBedCount(h.beds[wardKey].available + delta, h.beds[wardKey].total);
          return {
            ...h,
            lastUpdated: 'Live feed • Just now',
            beds: {
              ...h.beds,
              [wardKey]: { ...h.beds[wardKey], available: nextAvail }
            }
          };
        });
      });
    }, 4500);
    return () => clearInterval(interval);
  }, [liveTelemetry]);

  const handleResetDemoData = () => {
    setHospitals(INITIAL_HOSPITALS);
    setReservations({});
    setAuditLogs([]);
    setUserLocation(DEFAULT_USER_LOCATION);
    setTraumaFilter('all');
    setWardFilter('all');
    setSearchQuery('');
    setLiveTelemetry(false);
    setGeoStatus('Reset to baseline facility snapshot.');
  };

  const handleUseBrowserGps = () => {
    if (!navigator.geolocation) {
      setGeoStatus('Browser geolocation unavailable; using Jubilee Hills reference.');
      return;
    }
    setGeoStatus('Acquiring GPS coordinates...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserLocation({
          lat: Number(pos.coords.latitude.toFixed(4)),
          lng: Number(pos.coords.longitude.toFixed(4)),
          label: 'Live GPS Coordinates'
        });
        setGeoStatus('Updated to live GPS coordinates.');
      },
      () => {
        setGeoStatus('Permission denied; using Jubilee Hills reference.');
      },
      { timeout: 6000 }
    );
  };

  const enrichedHospitals = useMemo(() => {
    const cleanQuery = sanitizeText(searchQuery).toLowerCase();
    const targetWard = wardFilter === 'all' ? 'icu' : wardFilter;

    return hospitals
      .map((hosp) => {
        const distanceKm = calculateHaversineDistance(
          userLocation.lat,
          userLocation.lng,
          hosp.lat,
          hosp.lng
        );
        const etaMinutes = estimateTravelMinutes(distanceKm);
        const triageScore = computeTriageScore(hosp, distanceKm, targetWard);
        return { ...hosp, distanceKm, etaMinutes, triageScore };
      })
      .filter((hosp) => {
        if (traumaFilter !== 'all' && hosp.traumaLevel !== traumaFilter) {
          return false;
        }

        if (cleanQuery) {
          const matchesName = hosp.name.toLowerCase().includes(cleanQuery);
          const matchesAddress = hosp.address.toLowerCase().includes(cleanQuery);
          const matchesSpec = hosp.specialties.some((s) => s.toLowerCase().includes(cleanQuery));
          if (!matchesName && !matchesAddress && !matchesSpec) return false;
        }

        if (onlyAvailable) {
          if (wardFilter !== 'all') {
            return hosp.beds[wardFilter].available > 0;
          }
          const openTotal =
            hosp.beds.icu.available +
            hosp.beds.general.available +
            hosp.beds.nicu.available +
            hosp.beds.isolation.available;
          return openTotal > 0;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'triage') return b.triageScore - a.triageScore;
        if (sortBy === 'icu') return b.beds.icu.available - a.beds.icu.available;
        if (sortBy === 'general') return b.beds.general.available - a.beds.general.available;
        return a.distanceKm - b.distanceKm;
      });
  }, [hospitals, userLocation, searchQuery, wardFilter, traumaFilter, onlyAvailable, sortBy]);

  const kpis = useMemo(
    () =>
      hospitals.reduce(
        (acc, h) => {
          acc.icu += h.beds.icu.available;
          acc.general += h.beds.general.available;
          acc.nicu += h.beds.nicu.available;
          acc.isolation += h.beds.isolation.available;
          return acc;
        },
        { icu: 0, general: 0, nicu: 0, isolation: 0 }
      ),
    [hospitals]
  );

  const handleUpdateBedCount = (
    hospitalId,
    wardKey,
    newAvailable,
    note = 'System update',
    passcode = 'ADMIN2026'
  ) => {
    const target = hospitals.find((h) => h.id === hospitalId);
    if (!target) return;
    const clamped = clampBedCount(newAvailable, target.beds[wardKey].total);

    setHospitals((prev) =>
      prev.map((h) => {
        if (h.id !== hospitalId) return h;
        return {
          ...h,
          lastUpdated: 'Just now',
          beds: {
            ...h.beds,
            [wardKey]: { ...h.beds[wardKey], available: clamped }
          }
        };
      })
    );

    setAuditLogs((prev) => [
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        hospitalName: target.name,
        ward: wardKey,
        newAvailable: clamped,
        note,
        timestamp: new Date().toLocaleTimeString()
      },
      ...prev
    ]);

    if (apiConnected) {
      fetch(`/api/hospitals/${hospitalId}/beds`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'x-dispatch-token': passcode
        },
        body: JSON.stringify({ ward: wardKey, available: clamped, note })
      }).catch(() => {});
    }
  };

  const handleReserveBed = (hospitalId, wardKey) => {
    const target = hospitals.find((h) => h.id === hospitalId);
    if (!target || target.beds[wardKey].available <= 0 || reservations[hospitalId]) return;

    const code = `CC-${Math.floor(1000 + Math.random() * 9000)}`;
    handleUpdateBedCount(
      hospitalId,
      wardKey,
      target.beds[wardKey].available - 1,
      `Emergency bed hold (${code})`
    );
    setReservations((prev) => ({ ...prev, [hospitalId]: { ward: wardKey, code } }));
  };

  const handleReleaseBed = (hospitalId) => {
    const existing = reservations[hospitalId];
    const target = hospitals.find((h) => h.id === hospitalId);
    if (!existing || !target) return;

    handleUpdateBedCount(
      hospitalId,
      existing.ward,
      target.beds[existing.ward].available + 1,
      `Released hold (${existing.code})`
    );
    setReservations((prev) => {
      const next = { ...prev };
      delete next[hospitalId];
      return next;
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-600 rounded-lg">
              <HeartPulse className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-base sm:text-lg leading-tight">
                CareCompass: BedFinder Blitz
              </h1>
              <p className="text-[11px] text-slate-400">
                Real-Time Emergency Bed Triage &amp; Haversine Proximity Routing
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span
              className={`hidden sm:inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium border ${
                apiConnected
                  ? 'bg-emerald-950/60 text-emerald-300 border-emerald-700/60'
                  : 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              <Server className="w-3 h-3" />
              {apiConnected ? 'API Synced' : 'Standalone Mode'}
            </span>

            <button
              onClick={() => setLiveTelemetry((v) => !v)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold transition ${
                liveTelemetry
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
            >
              <Radio className={`w-3.5 h-3.5 ${liveTelemetry ? 'animate-pulse' : ''}`} />
              {liveTelemetry ? 'Live Feed: ON' : 'Live Feed: OFF'}
            </button>

            <button
              onClick={handleResetDemoData}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition"
              title="Reset mock bed counts"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset
            </button>

            <nav className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-lg">
              <button
                onClick={() => setActiveTab('finder')}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition ${
                  activeTab === 'finder' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white'
                }`}
              >
                <BedDouble className="w-3.5 h-3.5" />
                Bed Finder
              </button>
              <button
                onClick={() => setActiveTab('admin')}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-semibold transition ${
                  activeTab === 'admin' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white'
                }`}
              >
                <Shield className="w-3.5 h-3.5" />
                Admin Console
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">Available ICU</div>
            <div className="text-2xl font-extrabold text-blue-600 mt-1">{kpis.icu}</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">General Ward</div>
            <div className="text-2xl font-extrabold text-emerald-600 mt-1">{kpis.general}</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">NICU / Pediatric</div>
            <div className="text-2xl font-extrabold text-indigo-600 mt-1">{kpis.nicu}</div>
          </div>
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
            <div className="text-xs font-semibold text-slate-500 uppercase">Isolation / ER</div>
            <div className="text-2xl font-extrabold text-amber-600 mt-1">{kpis.isolation}</div>
          </div>
        </section>

        {activeTab === 'admin' ? (
          <AdminConsole
            hospitals={hospitals}
            onUpdateBedCount={handleUpdateBedCount}
            auditLogs={auditLogs}
          />
        ) : (
          <>
            <section className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                <div className="md:col-span-4 relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search hospital, area, or specialty..."
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="md:col-span-2 flex items-center gap-1.5">
                  <SlidersHorizontal className="w-4 h-4 text-slate-400 shrink-0" />
                  <select
                    value={wardFilter}
                    onChange={(e) => setWardFilter(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  >
                    <option value="all">All Wards</option>
                    <option value="icu">ICU Beds</option>
                    <option value="general">General</option>
                    <option value="nicu">NICU</option>
                    <option value="isolation">Isolation</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <select
                    value={traumaFilter}
                    onChange={(e) => setTraumaFilter(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  >
                    <option value="all">All Trauma Levels</option>
                    <option value="Level I Trauma">Level I Trauma</option>
                    <option value="Level II Trauma">Level II Trauma</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full px-2.5 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  >
                    <option value="triage">Sort: Triage Score</option>
                    <option value="distance">Sort: Nearest</option>
                    <option value="icu">Sort: Most ICU</option>
                    <option value="general">Sort: Most General</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <button
                    onClick={handleUseBrowserGps}
                    className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-lg transition h-full"
                  >
                    <LocateFixed className="w-3.5 h-3.5 text-blue-600" />
                    Use My GPS
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
                <label className="inline-flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                  <input
                    type="checkbox"
                    checked={onlyAvailable}
                    onChange={(e) => setOnlyAvailable(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  Show only facilities with available beds
                </label>

                <span className="text-slate-500">
                  Origin: <strong>{userLocation.label}</strong> ({userLocation.lat}, {userLocation.lng})
                  {geoStatus && <span className="text-blue-600 ml-2">• {geoStatus}</span>}
                </span>
              </div>
            </section>

            <HospitalMap
              hospitals={enrichedHospitals}
              userLocation={userLocation}
              selectedHospitalId={selectedHospitalId}
              onSelectHospital={setSelectedHospitalId}
            />

            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-slate-900 text-base">
                  Matched Facilities ({enrichedHospitals.length})
                </h2>
                <span className="text-xs text-slate-500">
                  Ranked by Triage Suitability &amp; Haversine Distance
                </span>
              </div>

              {enrichedHospitals.length === 0 ? (
                <div className="bg-white border border-slate-200 rounded-xl p-8 text-center">
                  <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="font-semibold text-slate-800">No hospitals match your filters.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {enrichedHospitals.map((hospital) => (
                    <HospitalCard
                      key={hospital.id}
                      hospital={hospital}
                      isSelected={hospital.id === selectedHospitalId}
                      onSelect={setSelectedHospitalId}
                      onReserveBed={handleReserveBed}
                      onReleaseBed={handleReleaseBed}
                      activeReservation={reservations[hospital.id]}
                    />
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </main>
    </div>
  );
}
